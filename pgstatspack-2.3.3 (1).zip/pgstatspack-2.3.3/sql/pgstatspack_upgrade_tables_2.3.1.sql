SET client_min_messages TO error;
-- Upgrade pgstatspack schema tables.	
--
-- By uwe.bartels@gmail.com
--

insert into pgstatspack_version values('2.3.1');

