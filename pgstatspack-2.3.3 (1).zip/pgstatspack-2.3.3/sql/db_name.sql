select datname from pg_database where datname not like 'template%';
